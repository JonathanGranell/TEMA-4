#ifndef MYCALC
#define MYCALC 

int suma(int a, int b);
int resta(int a, int b);
int multiplica(int a, int b);
int dividir(int a, int b);
int major(int a, int b);
#endif